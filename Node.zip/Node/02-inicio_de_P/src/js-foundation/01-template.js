const emailTemplate = `<div>
    <h1>Hola {{name}}</h1>
    <p>Thank you for your order</p>
    <button></button>
</div>`;
//console.log(emailTemplate);
module.exports = {
        emailTemplate
}