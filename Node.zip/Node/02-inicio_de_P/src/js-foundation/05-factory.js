//const { getAge, generateUuid } = require('../plugins')
// const obj = {name:'jhon',birthdate: '2000-06-12'};
// const ola = buildPerson(obj);
// console.log(ola);

const buildMakePerson = ({generateUuid, getAge}) => {
    return ({name, birthdate}) => {
        return {
            id : generateUuid(),
            name: name,
            birthdate: birthdate,
            age: getAge(birthdate),
        }
    }
}




module.exports={
    buildMakePerson,
}