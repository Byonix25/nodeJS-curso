const { generateUuid, getAge} = require('./plugins')
const { buildMakePerson } = require('./js-foundation/05-factory');
const {getPokemonById}=require('./js-foundation/06-promises')

getPokemonById(4)
.then( (pokemon)=>console.log({pokemon}) )
.catch( (error)=>console.log({error}) )
.finally ( () => console.log( 'Finalmente ' )) 

//!Referencia a la funcion factory y uso con dependencias
// const hacerperson = buildMakePerson({generateUuid , getAge});

// const obj = {name:'esteban',birthdate: '2000-06-12'};
// const esteban = hacerperson(obj);
// console.log({esteban});
