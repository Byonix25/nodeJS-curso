const { generateUuid } = require('./uuid-plugin');
const { getAge } = require('./getAgePlugin');

module.exports = {
    generateUuid,
    getAge,
}
