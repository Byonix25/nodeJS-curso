const users = [
    {
        id: 1,
        name: 'John'
    },
    {
        id: 2,
        name: 'Jane'
    }
];

function getUserById(id, callback) {
    const user = users.find( function(user) { 
        return user.id === id
})
    if (!user) {
        return callback(`USE id: ${id} does not exist`);
    }
    return callback(null, user);
}

module.exports = {
    getUserById,
}