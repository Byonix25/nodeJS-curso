const httpClientPlugin = {
    get: async(url) => {

    },
}

module.exports = {
    httpClientPlugin,
}