const fs = require('fs');
const content = fs.readFileSync('readme.md', 'utf8');
const wordCount = content.split(' ');
//const wordCountReact = wordCount.filter( word => word.toLowerCase().includes('react'));
const wordCountReact = content.match(/react/gi);
console.log('La cantidad de palabras es:', wordCount.length);
console.log('La cantidad de palabras React es:', wordCountReact.length);
