const message = "hola mundo";

console.log(message);