const users = [
    {
        id: 1,
        name: 'John'
    },
    {
        id: 2,
        name: 'Jane'
    }
];

const getUserById = (id, callback) => {
    const user = users.find( user => user.id === id);
    (!user) ?  callback(`USUARIO id: ${id} does not exist`) : callback(null, user);
}

module.exports = {
    getUserById,
}