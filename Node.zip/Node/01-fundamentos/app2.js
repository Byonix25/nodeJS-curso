const fs = require('fs');
const data = fs.readFileSync('readme.md', 'utf8');
const newData = data.replace(/React/ig, 'angular');

fs.writeFileSync('readme-Angular.md', newData)
//console.log(newData);
