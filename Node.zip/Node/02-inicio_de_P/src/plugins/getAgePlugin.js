const getAgePlugin = require('get-Age');
const getAge = (birthdate) => {
    (!birthdate) ? new Error('birthdate is required') : getAgePlugin(birthdate);
}
module.exports={
    getAge,
}